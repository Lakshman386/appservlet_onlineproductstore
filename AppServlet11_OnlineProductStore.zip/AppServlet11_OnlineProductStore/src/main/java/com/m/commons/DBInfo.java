package com.m.commons;

public interface DBInfo {

	public static final String dbUrl = "jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String uName = "c##mani";
	public static final String pWord = "manikanth";
}
